package ModifierPack2;
import ModifierPack1.*;
public class AccessSpecifier1 extends ProAccesss{
public static void main(String[] args) {
			AccessSpecifier1 obj = new AccessSpecifier1 ();   
		       obj.display();  
		}

	}



