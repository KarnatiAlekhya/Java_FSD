package ModifierPack2;
import ModifierPack1.*;
public class AccessSpecifier2 {
	

	

		public static void main(String[] args) {
			
			PubAccess obj = new PubAccess(); 
	        obj.display();  
			
		}
	}


