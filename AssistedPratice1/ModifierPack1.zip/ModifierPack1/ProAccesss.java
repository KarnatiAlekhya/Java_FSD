package ModifierPack1;

public class ProAccesss {
	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}



