package Maps;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.TreeMap;

public class MapsProgram {
public static void main(String[] args) {
				
					HashMap<Integer,String> hm=new HashMap<Integer,String>();      
				      hm.put(1,"Alekhya");    
				      hm.put(2,"java");    
				      hm.put(3,"training");   
				       
				      System.out.println("\nThe elements of Hashmap are ");  
				      for(Map.Entry m:hm.entrySet()){    
				       System.out.println(m.getKey()+" "+m.getValue());    
				      }
				      
				     //HashTable
				       
				      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
				      
				      ht.put(4,"Java language");  
				      ht.put(5,"fsd");  
				      ht.put(6,"comapany");  
				      ht.put(7,"Lekha");  

				      System.out.println("\nThe elements of HashTable are ");  
				      for(Map.Entry n:ht.entrySet()){    
				       System.out.println(n.getKey()+" "+n.getValue());    
				      }
				      
				      
				      //TreeMap
				      
				      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
				      map.put(8,"Lucky");    
				      map.put(9,"Chandu");    
				      map.put(10,"Ashok");       
				      
				      System.out.println("\nThe elements of TreeMap are ");  
				      for(Map.Entry l:map.entrySet()){    
				       System.out.println(l.getKey()+" "+l.getValue());    
				      }    
				      
				   }  



			}


