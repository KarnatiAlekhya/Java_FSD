package AccessModifier;

public class Specifier {
	public static void main(String[] args) {
		//private
		System.out.println("Private Access Specifier");
		Specifier  obj = new Specifier(); 
        //trying to access private method of another class 
        //obj.display();

	}
}




