package AccessModifier;

public class accessSpecifier {
	public static void main(String[] args) {
		//default
		System.out.println("Dafault Access Specifier");
		accessSpecifier obj = new accessSpecifier(); 		  
        obj.display(); 

	}

	private void display() {
		// TODO Auto-generated method stub
		
	}
}


